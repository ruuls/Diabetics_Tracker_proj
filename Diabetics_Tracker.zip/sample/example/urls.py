from django.urls import path
from . import views

urlpatterns = [
    #path('', views.get_name, name='home-page'),
    path('', views.home, name='home-page'),
    path('add',views.add,name='add')
]
